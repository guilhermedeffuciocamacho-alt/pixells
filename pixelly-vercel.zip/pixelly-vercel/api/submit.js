const rateStore = globalThis.__pixellyRateStore || new Map();
globalThis.__pixellyRateStore = rateStore;

const WINDOW_MS = 60_000;
const MAX_REQUESTS_PER_WINDOW = 3;
const SUCCESS_COOLDOWN_MS = 15_000;

function getClientIp(req) {
  const forwarded = req.headers['x-forwarded-for'] || req.headers['x-real-ip'] || '';
  return String(forwarded).split(',')[0].trim().slice(0, 80) || 'unknown';
}

function clean(value, max) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}

function validContact(value) {
  return /^[0-9+() .-]{8,30}$/.test(value);
}

function sameOriginAllowed(req) {
  const origin = req.headers.origin;
  if (!origin) return true; // Some browsers/tools omit Origin on same-site requests.
  try {
    const originUrl = new URL(origin);
    const host = req.headers.host;
    return originUrl.host === host;
  } catch {
    return false;
  }
}

function reply(res, status, message) {
  return res.status(status).json({ ok: status < 400, message });
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return reply(res, 405, 'Método não permitido.');
  }

  if (!sameOriginAllowed(req)) {
    return reply(res, 403, 'Origem não autorizada.');
  }

  const ip = getClientIp(req);
  const now = Date.now();
  const current = rateStore.get(ip);

  if (current && now - current.windowStart < WINDOW_MS) {
    if (current.count >= MAX_REQUESTS_PER_WINDOW) {
      const waitSeconds = Math.max(1, Math.ceil((WINDOW_MS - (now - current.windowStart)) / 1000));
      res.setHeader('Retry-After', String(waitSeconds));
      return reply(res, 429, `Muitas tentativas. Aguarde ${waitSeconds}s.`);
    }
    current.count += 1;
  } else {
    rateStore.set(ip, { windowStart: now, count: 1, lastSuccess: 0 });
  }

  const record = rateStore.get(ip);
  const body = req.body || {};

  // Honeypot catches common bots without annoying real visitors.
  if (clean(body.website, 120)) {
    return reply(res, 400, 'Não foi possível processar este envio.');
  }

  // Prevent a successful submit from being immediately repeated.
  if (record.lastSuccess && now - record.lastSuccess < SUCCESS_COOLDOWN_MS) {
    const waitSeconds = Math.max(1, Math.ceil((SUCCESS_COOLDOWN_MS - (now - record.lastSuccess)) / 1000));
    res.setHeader('Retry-After', String(waitSeconds));
    return reply(res, 429, `Pedido já enviado. Aguarde ${waitSeconds}s.`);
  }

  const name = clean(body.name, 80);
  const company = clean(body.company, 120);
  const contact = clean(body.contact, 40);
  const type = clean(body.type, 60);
  const details = String(body.details ?? '').replace(/\r/g, '').trim().slice(0, 1800);

  if (!name || !company || !contact || !details) {
    return reply(res, 400, 'Preencha todos os campos obrigatórios.');
  }

  if (name.length < 2 || company.length < 2 || details.length < 10) {
    return reply(res, 400, 'Confira os dados informados.');
  }

  if (!validContact(contact)) {
    return reply(res, 400, 'Informe um WhatsApp ou contato válido.');
  }

  const webhook = process.env.DISCORD_WEBHOOK_URL;
  if (!webhook) {
    console.error('DISCORD_WEBHOOK_URL não configurada.');
    return reply(res, 500, 'O servidor ainda não configurou o recebimento dos pedidos.');
  }

  let webhookUrl;
  try {
    webhookUrl = new URL(webhook);
  } catch {
    return reply(res, 500, 'A configuração do webhook está inválida.');
  }

  if (webhookUrl.protocol !== 'https:' || webhookUrl.hostname !== 'discord.com') {
    return reply(res, 500, 'A configuração do webhook está inválida.');
  }

  const content = [
    '📩 **NOVO PEDIDO — PIXELLY**',
    '',
    `👤 **Nome:** ${name}`,
    `🏢 **Empresa:** ${company}`,
    `📱 **Contato:** ${contact}`,
    `🌐 **Tipo:** ${type || 'Não informado'}`,
    '',
    '📝 **Projeto:**',
    details,
    '',
    `🕒 **Recebido:** ${new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })}`,
  ].join('\n');

  try {
    const discordResponse = await fetch(webhookUrl.toString(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Pixelly-Vercel/1.0'
      },
      body: JSON.stringify({
        content,
        allowed_mentions: { parse: [] }
      })
    });

    if (!discordResponse.ok) {
      const text = await discordResponse.text();
      console.error('Discord webhook error:', discordResponse.status, text.slice(0, 500));
      return reply(res, 502, 'O pedido não pôde ser entregue ao Discord.');
    }

    record.lastSuccess = Date.now();
    return reply(res, 200, 'Pedido enviado com sucesso!');
  } catch (error) {
    console.error('Webhook request failed:', error);
    return reply(res, 502, 'Falha de comunicação. Tente novamente.');
  }
};
